import sys
import collections
import numpy as np
import heapq
import time
import numpy as np
global posWalls, posGoals
class PriorityQueue:
    """Define a PriorityQueue data structure that will be used"""
    def  __init__(self):
        self.Heap = []
        self.Count = 0
        self.len = 0

    def push(self, item, priority):
        entry = (priority, self.Count, item)
        heapq.heappush(self.Heap, entry)
        self.Count += 1

    def pop(self):
        (_, _, item) = heapq.heappop(self.Heap)
        return item

    def isEmpty(self):
        return len(self.Heap) == 0

"""Load puzzles and define the rules of sokoban"""

def transferToGameState(layout):
    """Transfer the layout of initial puzzle"""
    layout = [x.replace('\n','') for x in layout]
    layout = [','.join(layout[i]) for i in range(len(layout))]
    layout = [x.split(',') for x in layout]
    maxColsNum = max([len(x) for x in layout])
    for irow in range(len(layout)):
        for icol in range(len(layout[irow])):
            if layout[irow][icol] == ' ': layout[irow][icol] = 0   # free space
            elif layout[irow][icol] == '#': layout[irow][icol] = 1 # wall
            elif layout[irow][icol] == '&': layout[irow][icol] = 2 # player
            elif layout[irow][icol] == 'B': layout[irow][icol] = 3 # box
            elif layout[irow][icol] == '.': layout[irow][icol] = 4 # goal
            elif layout[irow][icol] == 'X': layout[irow][icol] = 5 # box on goal
        colsNum = len(layout[irow])
        if colsNum < maxColsNum:
            layout[irow].extend([1 for _ in range(maxColsNum-colsNum)]) 

    # print(layout)
    return np.array(layout)
def transferToGameState2(layout, player_pos):
    """Transfer the layout of initial puzzle"""
    maxColsNum = max([len(x) for x in layout])
    temp = np.ones((len(layout), maxColsNum))
    for i, row in enumerate(layout):
        for j, val in enumerate(row):
            temp[i][j] = layout[i][j]

    temp[player_pos[1]][player_pos[0]] = 2
    return temp

def PosOfPlayer(gameState):
    """Return the position of agent"""
    return tuple(np.argwhere(gameState == 2)[0]) # e.g. (2, 2)

def PosOfBoxes(gameState):
    """Return the positions of boxes"""
    return tuple(tuple(x) for x in np.argwhere((gameState == 3) | (gameState == 5))) # e.g. ((2, 3), (3, 4), (4, 4), (6, 1), (6, 4), (6, 5))

def PosOfWalls(gameState):
    """Return the positions of walls"""
    return tuple(tuple(x) for x in np.argwhere(gameState == 1)) # e.g. like those above

def PosOfGoals(gameState):
    """Return the positions of goals"""
    return tuple(tuple(x) for x in np.argwhere((gameState == 4) | (gameState == 5))) # e.g. like those above

def isEndState(posBox):
    """Check if all boxes are on the goals (i.e. pass the game)"""
    return sorted(posBox) == sorted(posGoals)

def isLegalAction(action, posPlayer, posBox):
    """Check if the given action is legal"""
    xPlayer, yPlayer = posPlayer
    if action[-1].isupper(): # the move was a push
        x1, y1 = xPlayer + 2 * action[0], yPlayer + 2 * action[1]
    else:
        x1, y1 = xPlayer + action[0], yPlayer + action[1]
    return (x1, y1) not in posBox + posWalls

def legalActions(posPlayer, posBox):
    """Return all legal actions for the agent in the current game state"""
    allActions = [[-1,0,'u','U'],[1,0,'d','D'],[0,-1,'l','L'],[0,1,'r','R']]
    xPlayer, yPlayer = posPlayer
    legalActions = []
    for action in allActions:
        x1, y1 = xPlayer + action[0], yPlayer + action[1]
        if (x1, y1) in posBox: # the move was a push
            action.pop(2) # drop the little letter
        else:
            action.pop(3) # drop the upper letter
        if isLegalAction(action, posPlayer, posBox):
            legalActions.append(action)
        else: 
            continue     

    return tuple(tuple(x) for x in legalActions) # e.g. ((0, -1, 'l'), (0, 1, 'R'))

def updateState(posPlayer, posBox, action):
    """Return updated game state after an action is taken"""
    xPlayer, yPlayer = posPlayer # the previous position of player
    newPosPlayer = [xPlayer + action[0], yPlayer + action[1]] # the current position of player
    posBox = [list(x) for x in posBox]
    if action[-1].isupper(): # if pushing, update the position of box
        posBox.remove(newPosPlayer)
        posBox.append([xPlayer + 2 * action[0], yPlayer + 2 * action[1]])
    posBox = tuple(tuple(x) for x in posBox)
    newPosPlayer = tuple(newPosPlayer)
    return newPosPlayer, posBox

def isFailed(posBox):
    """This function used to observe if the state is potentially failed, then prune the search"""
    rotatePattern = [[0,1,2,3,4,5,6,7,8],
                    [2,5,8,1,4,7,0,3,6],
                    [0,1,2,3,4,5,6,7,8][::-1],
                    [2,5,8,1,4,7,0,3,6][::-1]]
    flipPattern = [[2,1,0,5,4,3,8,7,6],
                    [0,3,6,1,4,7,2,5,8],
                    [2,1,0,5,4,3,8,7,6][::-1],
                    [0,3,6,1,4,7,2,5,8][::-1]]
    allPattern = rotatePattern + flipPattern

    for box in posBox:
        if box not in posGoals:
            board = [(box[0] - 1, box[1] - 1), (box[0] - 1, box[1]), (box[0] - 1, box[1] + 1), 
                    (box[0], box[1] - 1), (box[0], box[1]), (box[0], box[1] + 1), 
                    (box[0] + 1, box[1] - 1), (box[0] + 1, box[1]), (box[0] + 1, box[1] + 1)]
            for pattern in allPattern:
                newBoard = [board[i] for i in pattern]
                if newBoard[1] in posWalls and newBoard[5] in posWalls: return True
                elif newBoard[1] in posBox and newBoard[2] in posWalls and newBoard[5] in posWalls: return True
                elif newBoard[1] in posBox and newBoard[2] in posWalls and newBoard[5] in posBox: return True
                elif newBoard[1] in posBox and newBoard[2] in posBox and newBoard[5] in posBox: return True
                elif newBoard[1] in posBox and newBoard[6] in posBox and newBoard[2] in posWalls and newBoard[3] in posWalls and newBoard[8] in posWalls: return True
    return False

"""Implement all approcahes"""

def depthFirstSearch(gameState):
    """Implement depthFirstSearch approach"""
    # Lấy vị trí ban đầu của các thùng từ gameState
    beginBox = PosOfBoxes(gameState)
    # Lấy vị trí ban đầu của người chơi từ gameState
    beginPlayer = PosOfPlayer(gameState)

    # Tạo trạng thái bắt đầu bao gồm vị trí người chơi và vị trí thùng
    startState = (beginPlayer, beginBox)
    # Tạo hàng đợi frontier cho DFS, chứa trạng thái ban đầu
    frontier = collections.deque([[startState]])
    # Tạo tập hợp để theo dõi các trạng thái đã xét
    exploredSet = set()
    # Tạo hàng đợi để lưu các hành động tương ứng, bắt đầu với hành động giả [0]
    actions = [[0]] 
    # Khởi tạo danh sách tạm để lưu kết quả cuối cùng
    temp = []
    
    # Vòng lặp chính của thuật toán DFS
    while frontier:
        # Lấy ra đường đi ở cuối hàng đợi (LIFO - Last In First Out cho DFS)
        node = frontier.pop()
        # Lấy ra chuỗi hành động tương ứng
        node_action = actions.pop()
        
        # Kiểm tra nếu trạng thái cuối cùng trong đường đi là trạng thái kết thúc
        # node[-1][-1] truy cập vào vị trí thùng ở trạng thái cuối cùng
        if isEndState(node[-1][-1]):
            # Thêm các hành động vào temp (bỏ phần tử đầu tiên là 0)
            temp += node_action[1:]
            break
            
        # Nếu trạng thái cuối của đường đi chưa được khám phá
        if node[-1] not in exploredSet:
            # Thêm trạng thái vào tập đã khám phá
            exploredSet.add(node[-1])
            
            # Xét tất cả các hành động hợp lệ có thể thực hiện từ trạng thái hiện tại
            for action in legalActions(node[-1][0], node[-1][1]):
                # Cập nhật vị trí người chơi và thùng sau khi thực hiện hành động
                newPosPlayer, newPosBox = updateState(node[-1][0], node[-1][1], action)
                # Nếu vị trí thùng mới tạo ra deadlock (thùng không thể di chuyển tiếp), bỏ qua
                if isFailed(newPosBox):
                    continue
                    
                # Thêm trạng thái mới vào frontier
                frontier.append(node + [(newPosPlayer, newPosBox)])
                # Thêm hành động mới vào danh sách actions
                # action[-1] lấy ký tự cuối cùng của action, đại diện cho hướng di chuyển
                # có thể là chữ hoa (đẩy thùng) hoặc chữ thường (di chuyển người)
                actions.append(node_action + [action[-1]])
    
    # In số lượng hành động trong giải pháp
    print(len(temp))
    # Trả về chuỗi hành động để giải bài toán
    return temp

def breadthFirstSearch(gameState):
    """Implement breadthFirstSearch approach"""
    # Lấy vị trí ban đầu của các thùng từ gameState
    beginBox = PosOfBoxes(gameState)
    # Lấy vị trí ban đầu của người chơi từ gameState
    beginPlayer = PosOfPlayer(gameState)

    # Tạo trạng thái bắt đầu bao gồm vị trí người chơi và vị trí thùng
    startState = (beginPlayer, beginBox)
    # Tạo hàng đợi frontier cho BFS, chứa trạng thái ban đầu
    frontier = collections.deque([[startState]])
    # Tạo tập hợp để theo dõi các trạng thái đã xét
    exploredSet = set()
    # Tạo hàng đợi để lưu các hành động tương ứng, bắt đầu với hành động giả [0]
    actions = collections.deque([[0]])
    # Khởi tạo danh sách tạm để lưu kết quả cuối cùng
    temp = []
    
    # Vòng lặp chính của thuật toán BFS
    while frontier:
        # Lấy đường đi và chuỗi hành động từ đầu hàng đợi (FIFO - First In First Out cho BFS)
        node = frontier.popleft()
        node_action = actions.popleft()
        
        # Kiểm tra xem state cuối có phải trạng thái đích không
        # node[-1][1] là vị trí của thùng tại trạng thái cuối cùng trong đường đi
        if isEndState(node[-1][1]):
            # Thêm các hành động vào temp (bỏ phần tử đầu tiên là 0)
            temp += node_action[1:]
            break
        
        # Nếu state cuối của đường đi chưa được khám phá
        if node[-1] not in exploredSet:
            # Thêm trạng thái vào tập đã khám phá
            exploredSet.add(node[-1])
            
            # Lặp qua các action khả dụng từ trạng thái hiện tại
            for action in legalActions(node[-1][0], node[-1][1]):
                # Cập nhật vị trí người chơi và thùng sau khi thực hiện hành động
                newPosPlayer, newPosBox = updateState(node[-1][0], node[-1][1], action)
                # Bỏ qua các state "chết" (deadlock)
                if isFailed(newPosBox):
                    continue
                
                # Tạo đường đi mới, thêm vào frontier
                newNode = node + [(newPosPlayer, newPosBox)]
                # Tạo chuỗi hành động mới
                # action[-1] lấy ký tự cuối cùng của action, đại diện cho hướng di chuyển
                newActions = node_action + [action[-1]]
                
                # Thêm vào cuối hàng đợi (khác với DFS thêm vào đầu)
                frontier.append(newNode)
                actions.append(newActions)

    # In số lượng hành động trong giải pháp
    print(len(temp))
    # Trả về chuỗi hành động để giải bài toán
    return temp

def cost(actions):
    # Hàm cost nhận vào một danh sách các hành động
    """A cost function"""
    # Trả về số lượng hành động là chữ thường (được hiểu là di chuyển người, không đẩy thùng)
    return len([x for x in actions if x.islower()])


def uniformCostSearch(gameState):
    # Hàm thực hiện thuật toán Tìm kiếm Chi phí Thống nhất (UCS) trên gameState
    """Implement uniformCostSearch approach"""  
    start = time.time() # Thời điểm bắt đầu (để tính thời gian chạy)

    num_of_nodes = 0
    # Biến đếm số lượng nút đã mở

    beginBox = PosOfBoxes(gameState)
    # Lấy danh sách vị trí các thùng từ trạng thái gameState

    beginPlayer = PosOfPlayer(gameState)
    # Lấy vị trí của người chơi từ trạng thái gameState

    startState = (beginPlayer, beginBox)
    # Tạo state khởi đầu gồm vị trí người chơi và danh sách vị trí các thùng

    frontier = PriorityQueue()
    # Tạo một hàng đợi ưu tiên, sẽ chứa các đường đi trong quá trình duyệt

    frontier.push([startState], 0)
    # Đưa đường đi bắt đầu (chỉ chứa startState) vào frontier với chi phí 0

    exploredSet = set()
    # Tạo tập hợp để đánh dấu các state đã được duyệt
    # Mỗi state là (vị trí người chơi, vị trí thùng)

    actions = PriorityQueue()
    # Tạo hàng đợi ưu tiên lưu các chuỗi hành động
    
    actions.push([0], 0)
    # Đưa hành động ban đầu [0] vào hàng đợi với chi phí 0 (mang tính giả, không ảnh hưởng)

    temp = []
    # Danh sách tạm để lưu lại lời giải (chuỗi hành động cuối cùng)

    num_of_nodes = 0
    # Số nút được duyệt, khởi tạo lại 0 (có thể do code cũ lặp biến)

    # Vòng lặp chính của UCS
    while not frontier.isEmpty():
        # Khi frontier còn dữ liệu, tiếp tục duyệt

        node = frontier.pop()
        # Lấy đường đi có chi phí nhỏ nhất (priority thấp nhất) từ frontier

        node_action = actions.pop()
        # Lấy chuỗi hành động tương ứng với đường đi trên

        if isEndState(node[-1][1]):
            # Kiểm tra xem các thùng trong state cuối đã ở vị trí goal hết chưa
            temp += node_action[1:]
            # Thêm các hành động (trừ phần tử đầu [0]) vào danh sách kết quả
            break
            # Thoát vòng lặp nếu tìm thấy giải pháp

        if node[-1] not in exploredSet:
            # Nếu state cuối của đường đi này chưa được duyệt

            exploredSet.add(node[-1])
            # Đánh dấu state này đã được duyệt

            num_of_nodes += 1
            # Tăng bộ đếm số nút đã mở

            for action in legalActions(node[-1][0], node[-1][1]):
                # Lấy tất cả hành động hợp lệ có thể thực hiện tại state cuối
                # node[-1][0] là vị trí người chơi, node[-1][1] là vị trí thùng

                newPosPlayer, newPosBox = updateState(node[-1][0], node[-1][1], action)
                # Cập nhật state mới sau khi thực hiện action
                # newPosPlayer là vị trí mới của người chơi
                # newPosBox là tập vị trí mới của các thùng

                if isFailed(newPosBox):
                    # Kiểm tra deadlock, nếu có thì bỏ qua
                    continue

                newNode = node + [(newPosPlayer, newPosBox)]
                # Tạo đường đi (node) mới bằng cách nối state mới vào node cũ

                newActions = node_action + [action[-1]]
                # Tạo chuỗi hành động mới bằng cách thêm ký tự (đại diện hướng di chuyển) vào chuỗi cũ

                newCost = cost(newActions[1:])
                # Tính chi phí mới bằng hàm cost (đếm các ký tự thường) 
                # Bỏ qua action đầu tiên [0]

                frontier.push(newNode, newCost)
                # Đưa đường đi mới vào frontier với chi phí newCost

                actions.push(newActions, newCost)
                # Đưa chuỗi hành động tương ứng vào actions với cùng chi phí

    end = time.time()
    # Lưu lại thời điểm kết thúc để tính thời gian

    print("Số hành động (giải pháp) UCS: ", len(temp))
    # In ra độ dài của chuỗi hành động tìm được
    print("Số nút mở của UCS: ", num_of_nodes)
    # In ra tổng số nút đã mở
    print('Runtime of UCS: %.4f second.' % (end - start))
    # In ra thời gian chạy của giải thuật UCS

    return temp
    # Trả về danh sách hành động cho lời giải

def heuristic(posPlayer, posBox):
    # Định nghĩa hàm heuristic với hai tham số: posPlayer (vị trí người chơi) và posBox (vị trí các thùng)
    # print(posPlayer, posBox)
    """A heuristic function to calculate the overall distance between the else boxes and the else goals"""
    # Chuỗi tài liệu (docstring) mô tả chức năng: Tính khoảng cách giữa các thùng còn lại và các vị trí goal còn lại

    distance = 0
    # Khởi tạo biến distance với giá trị 0, nhằm lưu tổng quãng đường cần di chuyển

    completes = set(posGoals) & set(posBox)
    # Tạo một tập hợp gồm những vị trí vừa là goal vừa đang có thùng (tức là đã hoàn thành)

    sortposBox = list(set(posBox).difference(completes))
    # Lọc ra danh sách thùng (posBox) chưa ở vị trí goal (loại bỏ những thùng đã hoàn thành hoàn toàn)

    sortposGoals = list(set(posGoals).difference(completes))
    # Lọc ra danh sách vị trí goal còn trống (chưa có thùng)

    for i in range(len(sortposBox)):
        # Duyệt qua các thùng chưa ở vị trí goal
        distance += (abs(sortposBox[i][0] - sortposGoals[i][0])) + (abs(sortposBox[i][1] - sortposGoals[i][1]))
        # Cộng thêm khoảng cách Manhattan giữa vị trí thùng và vị trí goal tương ứng

    return distance
    # Hoàn tất, trả về giá trị distance làm giá trị heuristic

def heuristicpro(posPlayer, posBox):
    """
    A more informed (and typically larger) heuristic than the basic one.
    This version:
    1) Ignores any boxes already on goals.
    2) Uses a greedy approach to pair each remaining box with its nearest goal.
    3) Also adds the distance from the player to the nearest unplaced box (optional improvement).
    """
    # Tách các box đã hoàn thành
    completes = set(posGoals) & set(posBox) #tao tập hợp các box đã ở vị trí của goal

    # Danh sách box và goal chưa hoàn thành
    unplaced_boxes = list(set(posBox) - completes) 
    empty_goals = list(set(posGoals) - completes)

    # Nếu không còn thùng nào cần di chuyển, heuristic = 0
    if not unplaced_boxes:
        return 0

    # Tính khoảng cách người chơi đến box gần nhất (một cải tiến nhỏ so với heuristic cũ)
    player_dist = min(abs(posPlayer[0] - b[0]) + abs(posPlayer[1] - b[1]) for b in unplaced_boxes)

    # Tính khoảng cách ghép greedy box <-> goal (mỗi box ghép với goal gần nhất)
    box_goal_dist = 0 # khởi tạo biến box_goal_dist với giá trị 0
    temp_goals = empty_goals[:] # tạo một bản sao của danh sách goal còn trống
    for box in unplaced_boxes: 
        # Tìm goal có khoảng cách Manhattan nhỏ nhất đến box này
        min_dist = float('inf') # khởi tạo min_dist với giá trị vô cực
        best_g = None # khởi tạo biến best_g với giá trị None
        for g in temp_goals: # duyệt qua các goal còn trống
            d = abs(box[0] - g[0]) + abs(box[1] - g[1]) # tính khoảng cách Manhattan giữa box và goal
            if d < min_dist: # nếu khoảng cách này nhỏ hơn min_dist hiện tại 
                min_dist = d # cập nhật min_dist
                best_g = g # lưu lại goal gần nhất
        if best_g: # nếu tìm thấy goal gần nhất 
            box_goal_dist += min_dist # cộng d vào box_goal_dist
            temp_goals.remove(best_g) # loại bỏ goal này khỏi danh sách goal còn trống

    # Tổng heuristic = khoảng cách người chơi tới box + tổng khoảng cách box <-> goal
    distance = player_dist + box_goal_dist
    return distance




def aStarSearch(gameState):
    """Implement aStarSearch approach"""
    start =  time.time() #bắt đầu tính thời gian thực thi

    num_of_nodes_astar = 0 
    # Khởi tạo bộ đếm số lượng node đã mở (expanded)

    beginBox = PosOfBoxes(gameState) 
    # Lấy vị trí mọi thùng (box) từ gameState ban đầu

    beginPlayer = PosOfPlayer(gameState)
    # Lấy vị trí của người chơi (player) từ gameState ban đầu

    temp = [] # khởi tạo danh sách tạm để lưu chuỗi hành động kết quả cuối cùng (giải pháp)

    start_state = (beginPlayer, beginBox) 
    # Tạo state khởi đầu từ vị trí player và vị trí các box

    frontier = PriorityQueue() # tạo hàng đợi ưu tiên cho các trạng thái cần xét
    # Cấu trúc dữ liệu lưu các state đang chờ duyệt (theo A*)

    frontier.push([start_state], heuristicpro(beginPlayer, beginBox)) # thêm trạng thái ban đầu vào hàng đợi với chi phí 0
    # Đưa state ban đầu vào priority queue với priority = heuristic

    exploredSet = set() # tạo tập hợp để theo dõi các trạng thái đã xét
    # Lưu các state đã được duyệt để tránh lặp

    actions = PriorityQueue() # tạo hàng đợi ưu tiên để lưu các hành động tương ứng
    # Lưu các chuỗi hành động kèm theo độ ưu tiên

    actions.push([0], heuristicpro(beginPlayer, start_state[1])) # thêm hành động giả [0] vào hàng đợi với chi phí 0
    # Đưa chuỗi hành động bắt đầu [0] với priority = heuristic

    while len(frontier.Heap) > 0: # vòng lặp chính của thuật toán A*
        # Lặp đến khi không còn state nào trong frontier

        node = frontier.pop() # lấy node có độ ưu tiên cao nhất từ hàng đợi , tức lấy đường đi (các state xếp chồng) có priority thấp nhất (A*)

        node_action = actions.pop() 
        # Lấy chuỗi hành động đi kèm

        if isEndState(node[-1][-1]): # nếu đã đến trạng thái đích
            # Kiểm tra xem box ở state cuối có đạt trạng thái goal

            temp += node_action[1:] # thêm các hành động vào temp (bỏ phần tử đầu tiên là 0)
            # Bỏ [0] rồi thêm vào kết quả

            break # thoát khỏi vòng lặp nếu đã tìm thấy giải pháp
            # Dừng vì đã tìm được đường đi

        ### CONTINUE YOUR CODE FROM HERE
        if node[-1] not in exploredSet: 
            # Kiểm tra nếu state cuối cùng của đường đi chưa được duyệt

            exploredSet.add(node[-1]) # thêm trạng thái vào tập đã khám phá đánh dấu state này là đã duyệt

            num_of_nodes_astar += 1
            # Tăng đếm số nút đã mở

            for action in legalActions(node[-1][0], node[-1][1]):
                # Lấy tất cả hành động hợp lệ từ vị trí player và box hiện tại

                newPosPlayer, newPosBox = updateState(node[-1][0], node[-1][1], action)
                # Tạo state mới sau khi thực hiện action

                if isFailed(newPosBox):
                    continue
                # Bỏ qua nếu trạng thái mới là deadlock (không mong muốn)

                newNode = node + [(newPosPlayer, newPosBox)]
                # Xây dựng đường đi (node) mới gồm node cũ + state mới

                newActions = node_action + [action[-1]]
                # Chuỗi hành động mới gồm action cũ + action hiện tại

                g = cost(newActions[1:])  # cost so far
                # Tính chi phí di chuyển (thường là số bước đi không đẩy box)

                h = heuristicpro(newPosPlayer, newPosBox)  # hoặc heuristicpro(...)
                # Tính heuristic (dựa trên khoảng cách box - goal)

                f = g + h
                # f là tổng cost + heuristic

                frontier.push(newNode, f)
                # Thêm đường đi mới vào danh sách frontier với độ ưu tiên f

                actions.push(newActions, f)
                # Thêm chuỗi hành động vào hàng đợi actions cũng với độ ưu tiên f

    end =  time.time()
    # Lấy thời gian kết thúc để tính thời gian chạy

    print("Số hành động (giải pháp) A*: ", len(temp))
    # In ra tổng số action có trong lời giải

    print("Số nút mở của A*: ", num_of_nodes_astar)
    # In ra tổng số node đã được mở

    print('Runtime of A*: %.4f second.' % (end - start))
    # In ra thời gian thực thi của hàm

    return temp
    # Trả về danh sách các action (solution) cho A*

"""Read command"""
def readCommand(argv):
    from optparse import OptionParser
    
    parser = OptionParser()
    parser.add_option('-l', '--level', dest='sokobanLevels',
                      help='level of game to play', default='level1.txt')
    parser.add_option('-m', '--method', dest='agentMethod',
                      help='research method', default='bfs')
    args = dict()
    options, _ = parser.parse_args(argv)
    with open('assets/levels/' + options.sokobanLevels,"r") as f: 
        layout = f.readlines()
    args['layout'] = layout
    args['method'] = options.agentMethod
    return args

def get_move(layout, player_pos, method):
    time_start = time.time()
    global posWalls, posGoals
    # layout, method = readCommand(sys.argv[1:]).values()
    gameState = transferToGameState2(layout, player_pos)
    posWalls = PosOfWalls(gameState)
    posGoals = PosOfGoals(gameState)
    
    if method == 'dfs':
        result = depthFirstSearch(gameState)
    elif method == 'bfs':        
        result = breadthFirstSearch(gameState)
    elif method == 'ucs':
        result = uniformCostSearch(gameState)
    elif method == 'astar':
        result = aStarSearch(gameState)        
    else:
        raise ValueError('Invalid method.')
    time_end=time.time()
    print('Runtime of %s: %.2f second.' %(method, time_end-time_start))
    print(result)
    return result
