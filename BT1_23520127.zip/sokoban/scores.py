import json

class Scores:
    def __init__(self, game):
        # Tham chiếu đến đối tượng Game để có thể truy cập self.game.index_level
        # và các phương thức của game (load_level, start, v.v.)
        self.game = game

    def load(self):
        try:
            # Mở file "scores" dưới dạng đọc (r)
            with open("scores", "r") as data:
                # Giải mã (parse) nội dung JSON trong file thành dict Python
                scores = json.load(data)

                # Lấy giá trị 'level' từ file, gán cho self.game.index_level
                self.game.index_level = scores["level"]

            # Sau khi đã gán level, tải lại level tương ứng
            self.game.load_level()
            # Chạy game luôn (start vòng lặp game)
            self.game.start()
        except FileNotFoundError:
            # Nếu file "scores" không tồn tại => thông báo
            print("No saved data")

    def save(self):
        # Chỉ lưu dữ liệu khi level hiện tại lớn hơn level trong file (nếu có)
        try:
            # Thử mở file "scores" để lấy level cũ
            with open("scores", "r") as data:
                scores = json.load(data)
                saved_level = scores["level"]
        except FileNotFoundError:
            # Nếu không có file => coi như saved_level = 0
            saved_level = 0

        # Nếu level hiện tại (self.game.index_level) lớn hơn level đã lưu => mới ghi file
        if saved_level < self.game.index_level:
            data = {
                "level": self.game.index_level
            }
            # Ghi nội dung JSON ra file "scores"
            with open("scores", "w") as scores:
                # ensure_ascii=False để cho phép ký tự UTF-8, indent=4 để format đẹp
                json.dump(data, scores, ensure_ascii=False, indent=4)
