import sys
import collections
import numpy as np
import heapq
import time
import numpy as np
global posWalls, posGoals

class PriorityQueue:
    """Define a PriorityQueue data structure that will be used"""
    def  __init__(self):
        # self.Heap: danh sách để cài đặt hàng đợi ưu tiên
        self.Heap = []
        # self.Count: dùng để đảm bảo khi priority giống nhau,
        # item nào push trước sẽ pop trước (tie-break)
        self.Count = 0
        self.len = 0   # Biến này không dùng đến trong code

    def push(self, item, priority):
        # entry = (độ ưu tiên, thứ tự xuất hiện, bản thân item)
        entry = (priority, self.Count, item)
        heapq.heappush(self.Heap, entry)
        self.Count += 1

    def pop(self):
        # Lấy ra phần tử có priority nhỏ nhất
        (_, _, item) = heapq.heappop(self.Heap)
        return item

    def isEmpty(self):
        return len(self.Heap) == 0

"""Load puzzles and define the rules of sokoban"""

def transferToGameState(layout):
    """Transfer the layout of initial puzzle"""
    # Hàm chuyển dạng ký tự từ file level thành ma trận số.
    layout = [x.replace('\n','') for x in layout]
    layout = [','.join(layout[i]) for i in range(len(layout))]
    layout = [x.split(',') for x in layout]
    maxColsNum = max([len(x) for x in layout])
    for irow in range(len(layout)):
        for icol in range(len(layout[irow])):
            if layout[irow][icol] == ' ': layout[irow][icol] = 0   # free space
            elif layout[irow][icol] == '#': layout[irow][icol] = 1 # wall
            elif layout[irow][icol] == '&': layout[irow][icol] = 2 # player
            elif layout[irow][icol] == 'B': layout[irow][icol] = 3 # box
            elif layout[irow][icol] == '.': layout[irow][icol] = 4 # goal
            elif layout[irow][icol] == 'X': layout[irow][icol] = 5 # box on goal
        colsNum = len(layout[irow])
        if colsNum < maxColsNum:
            # Lấp đầy bằng 1 (wall) nếu độ dài hàng thiếu so với maxColsNum
            layout[irow].extend([1 for _ in range(maxColsNum-colsNum)]) 

    return np.array(layout)

def transferToGameState2(layout, player_pos):
    """Transfer the layout of initial puzzle"""
    # Tương tự hàm trên, nhưng layout đã là mảng số,
    # và ta ghi đè thêm vị trí người chơi (player_pos).
    maxColsNum = max([len(x) for x in layout])
    temp = np.ones((len(layout), maxColsNum))
    for i, row in enumerate(layout):
        for j, val in enumerate(row):
            temp[i][j] = layout[i][j]

    # Ghi đè vị trí người chơi = 2
    temp[player_pos[1]][player_pos[0]] = 2
    return temp

def PosOfPlayer(gameState):
    """Return the position of agent"""
    # Tìm phần tử == 2 (player)
    return tuple(np.argwhere(gameState == 2)[0]) # e.g. (2, 2)

def PosOfBoxes(gameState):
    """Return the positions of boxes"""
    # Tìm tất cả vị trí == 3 (box) hoặc == 5 (box on goal)
    return tuple(tuple(x) for x in np.argwhere((gameState == 3) | (gameState == 5))) 

def PosOfWalls(gameState):
    """Return the positions of walls"""
    # Tìm tất cả vị trí == 1 (wall)
    return tuple(tuple(x) for x in np.argwhere(gameState == 1)) 

def PosOfGoals(gameState):
    """Return the positions of goals"""
    # Tìm tất cả vị trí == 4 (goal) hoặc == 5 (box on goal)
    return tuple(tuple(x) for x in np.argwhere((gameState == 4) | (gameState == 5))) 

def isEndState(posBox):
    """Check if all boxes are on the goals (i.e. pass the game)"""
    # So sánh danh sách toạ độ thùng (posBox) với danh sách toạ độ goal (posGoals)
    return sorted(posBox) == sorted(posGoals)

def isLegalAction(action, posPlayer, posBox):
    """Check if the given action is legal"""
    # Kiểm tra hành động có đẩy thùng hay không (chữ in hoa?)
    xPlayer, yPlayer = posPlayer
    if action[-1].isupper(): # the move was a push
        # Tính vị trí 2 ô phía trước
        x1, y1 = xPlayer + 2 * action[0], yPlayer + 2 * action[1]
    else:
        # Đi thường
        x1, y1 = xPlayer + action[0], yPlayer + action[1]
    # Hợp lệ nếu (x1, y1) không phải tường và không phải vị trí box
    return (x1, y1) not in posBox + posWalls

def legalActions(posPlayer, posBox):
    """Return all legal actions for the agent in the current game state"""
    # allActions = [dx, dy, ký_tự_thường, ký_tự_in_hoa]
    allActions = [[-1,0,'u','U'],
                  [1,0,'d','D'],
                  [0,-1,'l','L'],
                  [0,1,'r','R']]
    xPlayer, yPlayer = posPlayer
    legalActions = []
    for action in allActions:
        x1, y1 = xPlayer + action[0], yPlayer + action[1]
        if (x1, y1) in posBox: # the move was a push
            # Nếu ô kế tiếp có thùng => ta sẽ đẩy
            # => loại bỏ ký tự thường (pop vị trí thứ 2 trong list)
            action.pop(2)
        else:
            # Ngược lại chỉ di chuyển => loại bỏ ký tự in hoa (pop vị trí thứ 3)
            action.pop(3)
        if isLegalAction(action, posPlayer, posBox):
            legalActions.append(action)
        else: 
            continue     

    return tuple(tuple(x) for x in legalActions)

def updateState(posPlayer, posBox, action):
    """Return updated game state after an action is taken"""
    # Lấy vị trí người chơi cũ
    xPlayer, yPlayer = posPlayer
    # Vị trí mới người chơi sau action
    newPosPlayer = [xPlayer + action[0], yPlayer + action[1]]
    # Chuyển posBox sang list để chỉnh sửa
    posBox = [list(x) for x in posBox]
    if action[-1].isupper(): # if pushing, update the position of box
        # Xoá vị trí thùng cũ (nơi người chơi đẩy thùng)
        posBox.remove(newPosPlayer)
        # Thêm vị trí thùng mới
        posBox.append([xPlayer + 2 * action[0], yPlayer + 2 * action[1]])
    # Trả posBox về tuple để tránh thay đổi ngoài ý muốn
    posBox = tuple(tuple(x) for x in posBox)
    newPosPlayer = tuple(newPosPlayer)
    return newPosPlayer, posBox

def isFailed(posBox):
    """This function used to observe if the state is potentially failed, then prune the search"""
    # Sử dụng các pattern xoay, lật 3x3 để phát hiện deadlock
    rotatePattern = [[0,1,2,3,4,5,6,7,8],
                    [2,5,8,1,4,7,0,3,6],
                    [0,1,2,3,4,5,6,7,8][::-1],
                    [2,5,8,1,4,7,0,3,6][::-1]]
    flipPattern = [[2,1,0,5,4,3,8,7,6],
                    [0,3,6,1,4,7,2,5,8],
                    [2,1,0,5,4,3,8,7,6][::-1],
                    [0,3,6,1,4,7,2,5,8][::-1]]
    allPattern = rotatePattern + flipPattern

    for box in posBox:
        if box not in posGoals:
            board = [(box[0] - 1, box[1] - 1), (box[0] - 1, box[1]), (box[0] - 1, box[1] + 1), 
                    (box[0], box[1] - 1), (box[0], box[1]), (box[0], box[1] + 1), 
                    (box[0] + 1, box[1] - 1), (box[0] + 1, box[1]), (box[0] + 1, box[1] + 1)]
            for pattern in allPattern:
                newBoard = [board[i] for i in pattern]
                if newBoard[1] in posWalls and newBoard[5] in posWalls: return True
                elif newBoard[1] in posBox and newBoard[2] in posWalls and newBoard[5] in posWalls: return True
                elif newBoard[1] in posBox and newBoard[2] in posWalls and newBoard[5] in posBox: return True
                elif newBoard[1] in posBox and newBoard[2] in posBox and newBoard[5] in posBox: return True
                elif newBoard[1] in posBox and newBoard[6] in posBox and newBoard[2] in posWalls and newBoard[3] in posWalls and newBoard[8] in posWalls: return True
    return False

"""Implement all approcahes"""

def depthFirstSearch(gameState):
    """Implement depthFirstSearch approach"""
    # Lấy vị trí ban đầu của các thùng từ gameState
    beginBox = PosOfBoxes(gameState)
    # Lấy vị trí ban đầu của người chơi từ gameState
    beginPlayer = PosOfPlayer(gameState)

    # Tạo trạng thái bắt đầu bao gồm vị trí người chơi và vị trí thùng
    startState = (beginPlayer, beginBox)
    # Tạo hàng đợi frontier cho DFS, chứa trạng thái ban đầu
    frontier = collections.deque([[startState]])
    # Tạo tập hợp để theo dõi các trạng thái đã xét
    exploredSet = set()
    # Tạo hàng đợi để lưu các hành động tương ứng, bắt đầu với hành động giả [0]
    actions = [[0]] 
    # Khởi tạo danh sách tạm để lưu kết quả cuối cùng
    temp = []
    
    # Vòng lặp chính của thuật toán DFS
    while frontier:
        # Lấy ra đường đi ở cuối hàng đợi (LIFO - Last In First Out cho DFS)
        node = frontier.pop()
        # Lấy ra chuỗi hành động tương ứng
        node_action = actions.pop()
        
        # Kiểm tra nếu trạng thái cuối cùng trong đường đi là trạng thái kết thúc
        # node[-1][-1] truy cập vào vị trí thùng ở trạng thái cuối cùng
        if isEndState(node[-1][-1]):
            # Thêm các hành động vào temp (bỏ phần tử đầu tiên là 0)
            temp += node_action[1:]
            break
            
        # Nếu trạng thái cuối của đường đi chưa được khám phá
        if node[-1] not in exploredSet:
            # Thêm trạng thái vào tập đã khám phá
            exploredSet.add(node[-1])
            
            # Xét tất cả các hành động hợp lệ có thể thực hiện từ trạng thái hiện tại
            for action in legalActions(node[-1][0], node[-1][1]):
                # Cập nhật vị trí người chơi và thùng sau khi thực hiện hành động
                newPosPlayer, newPosBox = updateState(node[-1][0], node[-1][1], action)
                # Nếu vị trí thùng mới tạo ra deadlock (thùng không thể di chuyển tiếp), bỏ qua
                if isFailed(newPosBox):
                    continue
                    
                # Thêm trạng thái mới vào frontier
                frontier.append(node + [(newPosPlayer, newPosBox)])
                # Thêm hành động mới vào danh sách actions
                # action[-1] lấy ký tự cuối cùng của action, đại diện cho hướng di chuyển
                # có thể là chữ hoa (đẩy thùng) hoặc chữ thường (di chuyển người)
                actions.append(node_action + [action[-1]])
    
    # In số lượng hành động trong giải pháp
    print(len(temp))
    # Trả về chuỗi hành động để giải bài toán
    return temp

def breadthFirstSearch(gameState):
    """Implement breadthFirstSearch approach"""
    # Lấy vị trí ban đầu của các thùng từ gameState
    beginBox = PosOfBoxes(gameState)
    # Lấy vị trí ban đầu của người chơi từ gameState
    beginPlayer = PosOfPlayer(gameState)

    # Tạo trạng thái bắt đầu bao gồm vị trí người chơi và vị trí thùng
    startState = (beginPlayer, beginBox)
    # Tạo hàng đợi frontier cho BFS, chứa trạng thái ban đầu
    frontier = collections.deque([[startState]])
    # Tạo tập hợp để theo dõi các trạng thái đã xét
    exploredSet = set()
    # Tạo hàng đợi để lưu các hành động tương ứng, bắt đầu với hành động giả [0]
    actions = collections.deque([[0]])
    # Khởi tạo danh sách tạm để lưu kết quả cuối cùng
    temp = []
    
    # Vòng lặp chính của thuật toán BFS
    while frontier:
        # Lấy đường đi và chuỗi hành động từ đầu hàng đợi (FIFO - First In First Out cho BFS)
        node = frontier.popleft()
        node_action = actions.popleft()
        
        # Kiểm tra xem state cuối có phải trạng thái đích không
        # node[-1][1] là vị trí của thùng tại trạng thái cuối cùng trong đường đi
        if isEndState(node[-1][1]):
            # Thêm các hành động vào temp (bỏ phần tử đầu tiên là 0)
            temp += node_action[1:]
            break
        
        # Nếu state cuối của đường đi chưa được khám phá
        if node[-1] not in exploredSet:
            # Thêm trạng thái vào tập đã khám phá
            exploredSet.add(node[-1])
            
            # Lặp qua các action khả dụng từ trạng thái hiện tại
            for action in legalActions(node[-1][0], node[-1][1]):
                # Cập nhật vị trí người chơi và thùng sau khi thực hiện hành động
                newPosPlayer, newPosBox = updateState(node[-1][0], node[-1][1], action)
                # Bỏ qua các state "chết" (deadlock)
                if isFailed(newPosBox):
                    continue
                
                # Tạo đường đi mới, thêm vào frontier
                newNode = node + [(newPosPlayer, newPosBox)]
                # Tạo chuỗi hành động mới
                # action[-1] lấy ký tự cuối cùng của action, đại diện cho hướng di chuyển
                newActions = node_action + [action[-1]]
                
                # Thêm vào cuối hàng đợi (khác với DFS thêm vào đầu)
                frontier.append(newNode)
                actions.append(newActions)

    # In số lượng hành động trong giải pháp
    print(len(temp))
    # Trả về chuỗi hành động để giải bài toán
    return temp

def cost(actions):
    """A cost function"""
    # Đếm số action là chữ thường trong chuỗi hành động
    return len([x for x in actions if x.islower()])

def uniformCostSearch(gameState):
    """Implement uniformCostSearch approach"""
    # Lấy vị trí ban đầu của các thùng từ gameState
    beginBox = PosOfBoxes(gameState)
    # Lấy vị trí ban đầu của người chơi từ gameState
    beginPlayer = PosOfPlayer(gameState)

    # Tạo trạng thái bắt đầu bao gồm vị trí người chơi và vị trí thùng
    startState = (beginPlayer, beginBox)
    # Tạo hàng đợi ưu tiên cho UCS, đặt trạng thái ban đầu với chi phí 0
    frontier = PriorityQueue()
    frontier.push([startState], 0)
    # Tạo tập hợp để theo dõi các trạng thái đã xét
    exploredSet = set()
    # Tạo hàng đợi ưu tiên để lưu các hành động tương ứng, bắt đầu với hành động giả [0] và chi phí 0
    actions = PriorityQueue()
    actions.push([0], 0)
    # Khởi tạo danh sách tạm để lưu kết quả cuối cùng
    temp = []
    
    # Vòng lặp chính của thuật toán UCS
    while not frontier.isEmpty():
        # Lấy đường đi có chi phí nhỏ nhất từ hàng đợi ưu tiên
        node = frontier.pop()
        # Lấy chuỗi hành động tương ứng 
        node_action = actions.pop()
        
        # Nếu đã đến trạng thái đích
        if isEndState(node[-1][1]):
            # Thêm các hành động vào temp (bỏ phần tử đầu tiên là 0)
            temp += node_action[1:]
            break
        
        # Nếu chưa khám phá state cuối này
        if node[-1] not in exploredSet:
            # Thêm trạng thái vào tập đã khám phá
            exploredSet.add(node[-1])
            
            # Xét các action hợp lệ từ trạng thái hiện tại
            for action in legalActions(node[-1][0], node[-1][1]):
                # Cập nhật vị trí người chơi và thùng sau khi thực hiện hành động
                newPosPlayer, newPosBox = updateState(node[-1][0], node[-1][1], action)
                # Bỏ qua trạng thái deadlock
                if isFailed(newPosBox):
                    continue
                
                # Tạo đường đi mới
                newNode = node + [(newPosPlayer, newPosBox)]
                # Tạo chuỗi hành động mới
                newActions = node_action + [action[-1]]
                
                # Tính chi phí mới = số lần di chuyển người (không đẩy thùng)
                # Theo quy ước, chữ thường là di chuyển người
                newCost = cost(newActions[1:])  # Bỏ action "0" ở đầu
                
                # Thêm vào hàng đợi ưu tiên với chi phí tương ứng
                frontier.push(newNode, newCost)
                actions.push(newActions, newCost)

    # In số lượng hành động trong giải pháp
    print(len(temp))
    # Trả về chuỗi hành động để giải bài toán
    return temp

"""Read command"""
def readCommand(argv):
    from optparse import OptionParser
    
    parser = OptionParser()
    parser.add_option('-l', '--level', dest='sokobanLevels',
                      help='level of game to play', default='level1.txt')
    parser.add_option('-m', '--method', dest='agentMethod',
                      help='research method', default='bfs')
    args = dict()
    options, _ = parser.parse_args(argv)
    with open('assets/levels/' + options.sokobanLevels,"r") as f: 
        layout = f.readlines()
    args['layout'] = layout
    args['method'] = options.agentMethod
    return args

def get_move(layout, player_pos, method):
    time_start = time.time()
    global posWalls, posGoals
    # layout, method = readCommand(sys.argv[1:]).values()
    gameState = transferToGameState2(layout, player_pos)
    posWalls = PosOfWalls(gameState)
    posGoals = PosOfGoals(gameState)
    
    if method == 'dfs':
        result = depthFirstSearch(gameState)
    elif method == 'bfs':        
        result = breadthFirstSearch(gameState)
    elif method == 'ucs':
        result = uniformCostSearch(gameState)
    else:
        raise ValueError('Invalid method.')
    time_end = time.time()
    print('Runtime of %s: %.2f second.' %(method, time_end - time_start))
    print(result)
    return result
