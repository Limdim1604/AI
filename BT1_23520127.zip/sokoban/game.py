import pygame
import sys
from pygame.locals import *          # Import các hằng KEYDOWN, QUIT, v.v.
import constants as SOKOBAN          # File constants.py, chứa các hằng số cho game
from level import *                  # Lớp Level để quản lý cấu trúc bàn chơi
from player import *                 # Lớp Player để quản lý người chơi
from scores import *                 # Lớp Scores để quản lý điểm/số liệu
from player_interface import *       # Lớp PlayerInterface để quản lý giao diện người chơi
from solver import *                 # Chứa các hàm tìm kiếm DFS, BFS, UCS
from pyautogui import press, typewrite, hotkey

import _thread
import time

def move(threadName, delay, strategy):
    # Hàm phụ trợ, dùng để tự động nhấn phím (trái, phải, lên, xuống)
    # theo danh sách hành động (strategy) được trả về từ solver
    for step in strategy:
        if step in ['R','r']:
            press('right')
        if step in ['L','l']:
            press('left')
        if step in ['D','d']:
            press('down')
        if step in ['U','u']:
            press('up')
        # time.sleep(0.2)  # Có thể tạm dừng giữa các nước đi

class Game:
    def __init__(self, window):
        # window là đối tượng surface chính của pygame, nơi mọi thứ sẽ được vẽ
        self.window = window

        # Hàm nạp các ảnh textures (tường, thùng, mục tiêu, v.v.)
        self.load_textures()

        self.player = None            # Sẽ được khởi tạo khi load_level
        self.index_level = 1          # Màn chơi bắt đầu từ level 1
        self.load_level()             # Đọc file bản đồ, tạo đối tượng Level

        self.play = True              # Cờ để xác định game còn chạy hay không
        self.scores = Scores(self)    # Quản lý lưu/đọc dữ liệu (level)
        self.player_interface = PlayerInterface(self.player, self.level)
        # player_interface giúp vẽ menu nhỏ, undo, reset, auto, v.v.

    def load_textures(self):
       # Đọc các file ảnh, convert_alpha() để xử lý trong suốt
       # và đưa vào dict self.textures với key là hằng số (WALL, BOX, TARGET, ...)
       self.textures = {
           SOKOBAN.WALL: pygame.image.load('assets/images/wall.png').convert_alpha(),
           SOKOBAN.BOX: pygame.image.load('assets/images/box.png').convert_alpha(),
           SOKOBAN.TARGET: pygame.image.load('assets/images/target.png').convert_alpha(),
           SOKOBAN.TARGET_FILLED: pygame.image.load('assets/images/valid_box.png').convert_alpha(),
           SOKOBAN.PLAYER: pygame.image.load('assets/images/player_sprites.png').convert_alpha()
       }

    def load_level(self):
        # Khởi tạo một đối tượng Level dựa trên self.index_level
        self.level = Level(self.index_level)

        # Tạo một bề mặt (surface) có kích thước đúng bằng kích thước bàn chơi
        self.board = pygame.Surface((self.level.width, self.level.height))

        # Nếu đã có player thì cập nhật vị trí của player theo level vừa load
        if self.player:
            self.player.pos = self.level.position_player
            self.player_interface.level = self.level
        else:
            # Chưa có player => tạo mới
            self.player = Player(self.level)

    def start(self):
        # Vòng lặp game chính, chạy liên tục khi self.play == True
        while self.play:
            # Chờ sự kiện (event) từ pygame: phím bấm, chuột, v.v.
            self.process_event(pygame.event.wait())
            # Sau khi xử lý sự kiện, cập nhật màn hình
            self.update_screen()

    def process_event(self, event):
        # event.type == QUIT: người dùng tắt cửa sổ
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

        # event.type == KEYDOWN: có phím được nhấn
        if event.type == KEYDOWN:

            if event.key == K_ESCAPE:
                # Nhấn ESC => dừng game
                self.play = False
            if event.key in [K_UP, K_DOWN, K_LEFT, K_RIGHT, K_z, K_s, K_q, K_d]:
                # Các phím mũi tên + z, s, q, d => di chuyển người chơi
                self.player.move(event.key, self.level, self.player_interface)
                # Kiểm tra đã thắng chưa (thùng có nằm hết trên mục tiêu không)
                if self.has_win():
                    # Nếu thắng => tăng chỉ số level lên 1
                    self.index_level += 1
                    # Ở đây giới hạn level tối đa là 16, sang level 17 thì quay lại 1
                    if (self.index_level == 17):
                        self.index_level = 1
                    # Ghi dữ liệu level vào file "scores"
                    self.scores.save()
                    # Tải level mới
                    self.load_level()

            if event.key == K_r:
                # Phím R => tải lại level hiện tại (chơi lại từ đầu)
                self.load_level()

            if event.key == K_l:
                # Phím L => "Undo" bước đi cuối
                self.level.cancel_last_move(self.player, self.player_interface)

        # event.type == MOUSEBUTTONUP => chuột nhả => giao diện có thể click
        if event.type == MOUSEBUTTONUP:
            self.player_interface.click(event.pos, self.level, self)

        # event.type == MOUSEMOTION => di chuyển chuột => cập nhật vị trí chuột
        if event.type == MOUSEMOTION:
            self.player_interface.mouse_pos = event.pos

    def update_screen(self):
        # Vẽ nền trắng trên self.board (diện tích đúng bằng bàn chơi)
        pygame.draw.rect(self.board, SOKOBAN.WHITE,
                         (0,0, self.level.width * SOKOBAN.SPRITESIZE,
                          self.level.height * SOKOBAN.SPRITESIZE))
        # Vẽ nền trắng trên cửa sổ game (window) toàn màn hình
        pygame.draw.rect(self.window, SOKOBAN.WHITE,
                         (0,0, SOKOBAN.WINDOW_WIDTH, SOKOBAN.WINDOW_HEIGHT))

        # Cho đối tượng level vẽ bản đồ, rồi player vẽ nhân vật lên self.board
        self.level.render(self.board, self.textures)
        self.player.render(self.board, self.textures)

        # Tính toạ độ để đặt self.board vào chính giữa cửa sổ game
        pox_x_board = (SOKOBAN.WINDOW_WIDTH / 2) - (self.board.get_width() / 2)
        pos_y_board = (SOKOBAN.WINDOW_HEIGHT / 2) - (self.board.get_height() / 2)

        # Vẽ self.board lên self.window (tại vị trí tính ở trên)
        self.window.blit(self.board, (pox_x_board, pos_y_board))

        # Giao diện người chơi (menu nhỏ...) được vẽ lên window
        self.player_interface.render(self.window, self.index_level)

        # Cuối cùng, lệnh flip() để cập nhật toàn bộ khung hình
        pygame.display.flip()

    def has_win(self):
        # Kiểm tra còn bao nhiêu ô mục tiêu chưa có thùng
        nb_missing_target = 0
        for y in range(len(self.level.structure)):
            for x in range(len(self.level.structure[y])):
                # Nếu vẫn còn ô TARGET => nb_missing_target++
                if self.level.structure[y][x] == SOKOBAN.TARGET:
                    nb_missing_target += 1

        # Trả về True nếu tất cả target đã được đặt thùng (không còn ô TARGET nào)
        return nb_missing_target == 0

    def auto_move(self):
        # Tự động giải câu đố bằng cách gọi hàm get_move(...) trong solver
        # 3 dòng dưới là ví dụ người ta có thể chuyển sang BFS, DFS, UCS
        #strategy = get_move(self.level.structure[:-1], self.level.position_player, 'dfs')
        #strategy = get_move(self.level.structure[:-1], self.level.position_player, 'bfs')
        strategy = get_move(self.level.structure[:-1], self.level.position_player, 'ucs')

        # (Có thể ghi kết quả tìm được vào file solverlevel...)
        # with open("assets/sokobanSolver/Solverlevel_" + str(self.index_level) + ".txt", 'w+') as solver_file:
        #     for listitem in strategy:
        #         solver_file.write('%s, ' % listitem)

        # Nếu tìm được chuỗi hành động, gọi hàm move(...) chạy trên luồng mới
        if strategy is not None:
            try:
                _thread.start_new_thread(move, ("Thread-1", 2, strategy))
            except:
                print("Error: unable to start thread")


# Define a function for the thread
