import pygame
from pygame.locals import *
import constants as SOKOBAN          # Chứa các hằng số dùng cho game (màu, kích thước, v.v.)
from game import *                   # Import lớp Game để chạy chính game Sokoban

class Menu:
    def __init__(self):
        # Nạp hình ảnh menu background từ file 'assets/images/menu.png', convert_alpha() để hỗ trợ trong suốt
        self.image = pygame.image.load('assets/images/menu.png').convert_alpha()

        # Dòng chữ hiển thị trên menu
        self.new_game_txt = "New Game"
        self.load_game_txt = "Continue"
        self.quit_game_txt = "Quit"

        # Thiết lập font chữ (đọc file font 'FreeSansBold.ttf', cỡ 30)
        self.font = pygame.font.Font('assets/fonts/FreeSansBold.ttf', 30)

    def click(self, click_pos, window):
        # Hàm kiểm tra xem vị trí chuột click có nằm trên 3 nút "New Game", "Continue" hay "Quit" không.
        x = click_pos[0]
        y = click_pos[1]

        # Kiểm tra khu vực nút New Game
        if x > self.new_game_txt_position[0] and x < self.new_game_txt_position[0] + self.new_game_txt_surface.get_width() \
        and y > 300 and y < 300 + self.new_game_txt_surface.get_height():
            # Nếu click vào "New Game", tạo đối tượng Game và gọi start() để bắt đầu game
            sokoban = Game(window)
            sokoban.start()

        # Kiểm tra khu vực nút Continue
        elif x > self.load_game_txt_position[0] and x < self.load_game_txt_position[0] + self.load_game_txt_surface.get_width() \
        and y > 370 and y < 370 + self.load_game_txt_surface.get_height():
            # Nếu click "Continue", tạo đối tượng Game, load save trong file "scores", rồi start game
            sokoban = Game(window)
            sokoban.scores.load()

        # Kiểm tra khu vực nút Quit
        elif x > self.quit_game_txt_position[0] and x < self.quit_game_txt_position[0] + self.quit_game_txt_surface.get_width() \
        and y > 440 and y < 440 + self.quit_game_txt_surface.get_height():
            # Nếu click "Quit", trả về False để thoát vòng lặp menu
            return False

        # Nếu không click vào nút nào, vẫn tiếp tục chạy
        return True

    def render(self, window):
        # Vẽ background menu (self.image) ở góc (0,0)
        window.blit(self.image, (0,0))

        # Tạo đối tượng Surface cho mỗi dòng chữ, với màu chữ BLACK trên nền WHITE
        self.new_game_txt_surface = self.font.render(self.new_game_txt, True, SOKOBAN.BLACK, SOKOBAN.WHITE)
        # Tính vị trí để chữ New Game ở giữa màn hình, toạ độ y=300
        self.new_game_txt_position = ((SOKOBAN.WINDOW_WIDTH / 2) - (self.new_game_txt_surface.get_width() / 2), 300)
        # Vẽ chữ New Game
        window.blit(self.new_game_txt_surface, self.new_game_txt_position)

        self.load_game_txt_surface = self.font.render(self.load_game_txt, True, SOKOBAN.BLACK, SOKOBAN.WHITE)
        self.load_game_txt_position = ((SOKOBAN.WINDOW_WIDTH / 2) - (self.load_game_txt_surface.get_width() / 2), 370)
        window.blit(self.load_game_txt_surface, self.load_game_txt_position)

        self.quit_game_txt_surface = self.font.render(self.quit_game_txt, True, SOKOBAN.BLACK, SOKOBAN.WHITE)
        self.quit_game_txt_position = ((SOKOBAN.WINDOW_WIDTH / 2) - (self.quit_game_txt_surface.get_width() / 2), 440)
        window.blit(self.quit_game_txt_surface, self.quit_game_txt_position)


def main():
    # Khởi tạo pygame
    pygame.init()

    # Đặt chế độ lặp phím (độ trễ 300ms và lặp lại mỗi 150ms khi phím được giữ)
    pygame.key.set_repeat(300, 150)

    # Đặt tiêu đề cho cửa sổ game
    pygame.display.set_caption("Sokoban Game")

    # Tạo cửa sổ game với kích thước WINDOW_WIDTH x WINDOW_HEIGHT
    window = pygame.display.set_mode((SOKOBAN.WINDOW_WIDTH, SOKOBAN.WINDOW_HEIGHT))

    # Tạo đối tượng menu (Menu) để hiển thị menu chính
    menu = Menu()

    run = True
    while run:
        # Chờ 1 sự kiện của pygame (phím bấm, chuột, v.v.)
        event = pygame.event.wait()

        # Nếu sự kiện là người dùng tắt cửa sổ => thoát menu
        if event.type == QUIT:
            run = False

        # Nếu sự kiện là nhấn phím
        if event.type == KEYDOWN:
            # Phím J => chơi ngay 1 game mới
            if event.key == K_j:
                sokoban = Game(window)
                sokoban.start()
            # Phím C => tải dữ liệu đã lưu (scores) và chơi
            elif event.key == K_c:
                sokoban = Game(window)
                sokoban.scores.load()
            # Phím Escape => thoát menu
            elif event.key == K_ESCAPE:
                run = False

        # Nếu sự kiện là nhả chuột => kiểm tra user click nút nào
        if event.type == MOUSEBUTTONUP:
            # Hàm click() trong menu trả về True/False để tiếp tục hoặc thoát vòng lặp
            run = menu.click(event.pos, window)

        # Vẽ nền trắng toàn màn hình
        pygame.draw.rect(window, SOKOBAN.WHITE, (0,0,SOKOBAN.WINDOW_WIDTH,SOKOBAN.WINDOW_HEIGHT))

        # Vẽ menu (hình nền + các nút)
        menu.render(window)

        # Cập nhật khung hình
        pygame.display.flip()

    # Khi run = False, thoát vòng lặp => pygame.quit() đóng game
    pygame.quit()


# Khi file Sokoban.py được chạy trực tiếp, nó sẽ gọi main()
if __name__ == "__main__":
    main()
