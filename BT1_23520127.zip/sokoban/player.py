import pygame
from pygame.locals import *
import constants as SOKOBAN          # Chứa hằng số cấu hình game (vd: SPRITESIZE, AIR, WALL, BOX, ...)
from copy import deepcopy            # Dùng để sao chép sâu (deep copy) cấu trúc level trước khi thay đổi
import time

class Player:
    def __init__(self, level):
        # Lưu vị trí bắt đầu của người chơi (lấy từ level.position_player)
        self.pos = level.position_player
        # Hướng mặt của nhân vật, mặc định hướng DOWN (hướng xuống)
        self.direction = SOKOBAN.DOWN

    def move(self, direction, level, interface):
        # Lưu x, y là toạ độ hiện tại của người chơi
        x = self.pos[0]
        y = self.pos[1]

        # levelHasChanged cho biết có thay đổi gì lớn về cấu trúc không (ví dụ đẩy thùng)
        levelHasChanged = False

        # Sao lưu trạng thái bàn chơi (level.structure) trước khi thay đổi, 
        # dùng cho tính năng "undo" bước đi cuối
        previous_level_structure = deepcopy(level.structure)
        previous_player_pos = [x, y]

        # =============== Xử lý di chuyển (hoặc đẩy thùng) sang TRÁI ===============
        # Phím LEFT hoặc phím Q
        if direction == K_LEFT or direction == K_q:
            # Cập nhật hướng nhân vật sang LEFT
            self.direction = SOKOBAN.LEFT

            # (1) Kiểm tra ô bên trái x-1 có phải AIR hoặc TARGET không?
            #     Nếu đúng, ta chỉ cần di chuyển người chơi
            if x > 0 and level.structure[y][x - 1] in [SOKOBAN.AIR, SOKOBAN.TARGET]:
                self.pos[0] -= 1

            # (2) Nếu ô bên trái là BOX hoặc TARGET_FILLED, thì phải kiểm tra
            #     ô tiếp theo nữa (x-2) có trống (AIR hoặc TARGET) không => mới đẩy được
            elif x > 1 \
              and level.structure[y][x - 1] in [SOKOBAN.BOX, SOKOBAN.TARGET_FILLED] \
              and level.structure[y][x - 2] in [SOKOBAN.AIR, SOKOBAN.TARGET]:
                
                levelHasChanged = True
                # Nếu ô x-1 đang là TARGET_FILLED => chuyển thành TARGET
                # còn nếu là BOX trên ô thường => chuyển thành AIR
                if level.structure[y][x - 1] == SOKOBAN.TARGET_FILLED:
                    level.structure[y][x - 1] = SOKOBAN.TARGET
                else:
                    level.structure[y][x - 1] = SOKOBAN.AIR

                # Tương tự cho ô x-2 (nơi thùng sẽ được đẩy sang):
                if level.structure[y][x - 2] == SOKOBAN.TARGET_FILLED:
                    level.structure[y][x - 2] = SOKOBAN.TARGET
                elif level.structure[y][x - 2] == SOKOBAN.TARGET:
                    # Nếu ô x-2 là TARGET => sau khi đẩy thùng, nó thành TARGET_FILLED
                    level.structure[y][x - 2] = SOKOBAN.TARGET_FILLED
                else:
                    # Ngược lại nó trở thành BOX (thùng trên ô thường)
                    level.structure[y][x - 2] = SOKOBAN.BOX

                # Cuối cùng, người chơi (self.pos) di chuyển sang trái 1 ô
                self.pos[0] -= 1

        # =============== Xử lý di chuyển/đẩy thùng sang PHẢI ===============
        # Phím RIGHT hoặc phím D
        if direction == K_RIGHT or direction == K_d:
            self.direction = SOKOBAN.RIGHT
            if level.structure[y][x + 1] in [SOKOBAN.AIR, SOKOBAN.TARGET]:
                self.pos[0] += 1
            elif level.structure[y][x + 1] in [SOKOBAN.BOX, SOKOBAN.TARGET_FILLED] \
              and level.structure[y][x + 2] in [SOKOBAN.AIR, SOKOBAN.TARGET]:

                levelHasChanged = True
                if level.structure[y][x + 1] == SOKOBAN.TARGET_FILLED:
                    level.structure[y][x + 1] = SOKOBAN.TARGET
                else:
                    level.structure[y][x + 1] = SOKOBAN.AIR

                if level.structure[y][x + 2] == SOKOBAN.TARGET_FILLED:
                    level.structure[y][x + 2] = SOKOBAN.TARGET
                elif level.structure[y][x + 2] == SOKOBAN.TARGET:
                    level.structure[y][x + 2] = SOKOBAN.TARGET_FILLED
                else:
                    level.structure[y][x + 2] = SOKOBAN.BOX

                self.pos[0] += 1

        # =============== Xử lý di chuyển/đẩy thùng lên TRÊN ===============
        # Phím UP hoặc phím Z
        if direction == K_UP or direction == K_z:
            self.direction = SOKOBAN.UP
            if y > 0 and level.structure[y - 1][x] in [SOKOBAN.AIR, SOKOBAN.TARGET]:
                self.pos[1] -= 1
            elif y > 1 \
              and level.structure[y - 1][x] in [SOKOBAN.BOX, SOKOBAN.TARGET_FILLED] \
              and level.structure[y - 2][x] in [SOKOBAN.AIR, SOKOBAN.TARGET]:

                levelHasChanged = True
                if level.structure[y - 1][x] == SOKOBAN.TARGET_FILLED:
                    level.structure[y - 1][x] = SOKOBAN.TARGET
                else:
                    level.structure[y - 1][x] = SOKOBAN.AIR

                if level.structure[y - 2][x] == SOKOBAN.TARGET_FILLED:
                    level.structure[y - 2][x] = SOKOBAN.TARGET
                elif level.structure[y - 2][x] == SOKOBAN.TARGET:
                    level.structure[y - 2][x] = SOKOBAN.TARGET_FILLED
                else:
                    level.structure[y - 2][x] = SOKOBAN.BOX

                self.pos[1] -= 1

        # =============== Xử lý di chuyển/đẩy thùng xuống DƯỚI ===============
        # Phím DOWN hoặc phím S
        if direction == K_DOWN or direction == K_s:
            self.direction = SOKOBAN.DOWN
            if level.structure[y + 1][x] in [SOKOBAN.AIR, SOKOBAN.TARGET]:
                self.pos[1] += 1
            elif level.structure[y + 1][x] in [SOKOBAN.BOX, SOKOBAN.TARGET_FILLED] \
              and level.structure[y + 2][x] in [SOKOBAN.AIR, SOKOBAN.TARGET]:

                levelHasChanged = True
                if level.structure[y + 1][x] == SOKOBAN.TARGET_FILLED:
                    level.structure[y + 1][x] = SOKOBAN.TARGET
                else:
                    level.structure[y + 1][x] = SOKOBAN.AIR

                if level.structure[y + 2][x] == SOKOBAN.TARGET_FILLED:
                    level.structure[y + 2][x] = SOKOBAN.TARGET
                elif level.structure[y + 2][x] == SOKOBAN.TARGET:
                    level.structure[y + 2][x] = SOKOBAN.TARGET_FILLED
                else:
                    level.structure[y + 2][x] = SOKOBAN.BOX

                self.pos[1] += 1

        # Nếu có thay đổi lớn về cấu trúc (nghĩa là có đẩy thùng):
        if levelHasChanged:
            # Lưu cấu trúc bàn chơi cũ (trước khi di chuyển)
            level.last_structure_state = previous_level_structure
            # Lưu vị trí người chơi cũ
            level.last_player_pos = previous_player_pos
            # Đổi màu chữ "Undo" thành đen (cho biết có thể undo)
            interface.colorTxtCancel = SOKOBAN.BLACK

    def render(self, window, textures):
        # Tuỳ thuộc vào hướng self.direction, tính toạ độ cắt ảnh (top) khác nhau
        if self.direction == SOKOBAN.DOWN:
            top = 0
        elif self.direction == SOKOBAN.LEFT:
            top = SOKOBAN.SPRITESIZE
        elif self.direction == SOKOBAN.RIGHT:
            top = SOKOBAN.SPRITESIZE * 2
        elif self.direction == SOKOBAN.UP:
            top = SOKOBAN.SPRITESIZE * 3

        # Tạo hiệu ứng "chậm" nhẹ khi vẽ (không bắt buộc, có thể bỏ)
        time.sleep(0.1)

        # Cắt frame nhân vật từ sprite (có chiều rộng 32, chiều cao 32, toạ độ cắt (0, top))
        areaPlayer = pygame.Rect((0, top), (32, 32))

        # Vẽ player lên window, tại vị trí tương ứng: pos * SPRITESIZE
        # Tham số area=areaPlayer để chỉ vẽ đúng vùng nhân vật
        window.blit(textures[SOKOBAN.PLAYER],
                    (self.pos[0] * SOKOBAN.SPRITESIZE, self.pos[1] * SOKOBAN.SPRITESIZE),
                    area=areaPlayer)
