import pygame
import constants as SOKOBAN

class PlayerInterface:
    def __init__(self, player, level):
        # player: đối tượng Player, quản lý vị trí/hành động người chơi
        # level: đối tượng Level, quản lý cấu trúc màn chơi
        self.player = player
        self.level = level
        
        # Lưu vị trí chuột (mouse_pos) mặc định (-1, -1) tức là ngoài màn hình
        self.mouse_pos = (-1,-1)

        # self.font_menu: font chữ để hiển thị các dòng text bên cạnh
        self.font_menu = pygame.font.Font('assets/fonts/FreeSansBold.ttf', 18)

        # Dòng chữ hiển thị tên level trên màn hình
        self.txtLevel = "Level 1"
        self.colorTxtLevel = SOKOBAN.BLACK

        # Nút "Undo the last move"
        self.txtCancel = "Undo the last move"
        # Mặc định màu nút này là GREY (xám) – chỉ chuyển BLACK nếu có thể undo
        self.colorTxtCancel = SOKOBAN.GREY

        # Nút "Restart level"
        self.txtReset = "Restart level"
        self.colorTxtReset = SOKOBAN.BLACK

        # Nút "Auto"
        self.txtAuto = "Auto"
        self.colorTxtAuto = SOKOBAN.BLACK

    def click(self, pos_click, level, game):
        # Hàm này được gọi khi người dùng click chuột. Nó kiểm tra xem chuột
        # có nhấn vào nút "Undo", "Restart", hoặc "Auto" hay không.

        x = pos_click[0]
        y = pos_click[1]

        # 1) Cancel last move
        # So sánh toạ độ chuột với vùng vẽ (surface) của nút Cancel
        if x > self.posTxtCancel[0] and x < self.posTxtCancel[0] + self.txtCancelSurface.get_width() \
         and y > self.posTxtCancel[1] and y < self.posTxtCancel[1] + self.txtCancelSurface.get_height():
            # Nếu trùng, gọi hàm cancel_last_move để "undo"
            level.cancel_last_move(self.player, self)
            # Khi đã undo, màu nút chuyển sang xám
            self.colorTxtCancel = SOKOBAN.GREY

        # 2) Reset level
        # Tương tự, so sánh toạ độ chuột với vùng nút Reset
        if x > self.posTxtReset[0] and x < self.posTxtReset[0] + self.txtResetSurface.get_width() \
        and y > self.posTxtReset[1] and y < self.posTxtReset[1] + self.txtResetSurface.get_height():
            # Nếu khớp, gọi hàm load_level() của game để khởi động lại màn chơi
            game.load_level()
            
        # 3) Auto (tự động chạy giải thuật)
        # So sánh toạ độ chuột với vùng nút Auto
        if x > self.posTxtAuto[0] and x < self.posTxtAuto[0] + self.txtAutoSurface.get_width() \
        and y > self.posTxtAuto[1] and y < self.posTxtAuto[1] + self.txtAutoSurface.get_height():
            # Gọi game.auto_move() để sử dụng solver (DFS/BFS/UCS)
            game.auto_move()
                
    def setTxtColors(self):
        # Hàm này được đặt sẵn để đổi màu text nếu cần, nhưng hiện chưa dùng
        pass

    def render(self, window, level):
        # Hàm vẽ các dòng text lên màn hình (cửa sổ window).
        # Biến "level" ở đây là chỉ số màn chơi hiện tại (self.index_level).

        # 1) Render dòng "Level X"
        self.txtLevel = "Level " + str(level)
        # Tạo surface từ dòng text, màu chữ = self.colorTxtLevel, nền = WHITE
        self.txtLevelSurface = self.font_menu.render(self.txtLevel, True, self.colorTxtLevel, SOKOBAN.WHITE)
        # Vẽ text Level ở góc trái trên (10, 10)
        window.blit(self.txtLevelSurface, (10, 10))

        # 2) Render nút "Undo the last move"
        self.txtCancelSurface = self.font_menu.render(self.txtCancel, True, self.colorTxtCancel, SOKOBAN.WHITE)
        # Tính toạ độ hiển thị (nút nằm góc phải trên, lùi 10px)
        self.posTxtCancel = (SOKOBAN.WINDOW_WIDTH - self.txtCancelSurface.get_width() - 10, 10)
        window.blit(self.txtCancelSurface, self.posTxtCancel)

        # 3) Render nút "Restart level"
        self.txtResetSurface = self.font_menu.render(self.txtReset, True, self.colorTxtReset, SOKOBAN.WHITE)
        # Tính vị trí ở chính giữa trên
        self.posTxtReset = ((SOKOBAN.WINDOW_WIDTH / 2) - (self.txtResetSurface.get_width() / 2), 10)
        window.blit(self.txtResetSurface, self.posTxtReset)

        # 4) Render nút "Auto"
        self.txtAutoSurface = self.font_menu.render(self.txtAuto, True, self.colorTxtAuto, SOKOBAN.WHITE)
        # Đặt ở góc phải trên, bên dưới nút Undo một chút (toạ độ y = 30)
        self.posTxtAuto = ((SOKOBAN.WINDOW_WIDTH - self.txtAutoSurface.get_width()) - 10, 30)
        window.blit(self.txtAutoSurface, self.posTxtAuto)
