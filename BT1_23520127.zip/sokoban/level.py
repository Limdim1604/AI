import pygame                      # Thư viện pygame để xử lý đồ hoạ, sự kiện, v.v.
import constants as SOKOBAN       # Import file constants.py, chứa các hằng số cho game

class Level:
    def __init__(self, level_to_load):
        # last_structure_state sẽ lưu lại cấu trúc màn chơi (thứ tự ô, tường, thùng, ...)
        # trước khi người chơi di chuyển, nhằm hỗ trợ tính năng "undo" bước đi cuối cùng.
        self.last_structure_state = None  
        
        # Gọi hàm load(...) để đọc file bản đồ tương ứng với level được chỉ định.
        self.load(level_to_load)

    def load(self, level):
        # self.structure sẽ là danh sách 2 chiều, lưu từng dòng (hàng) bản đồ
        # Mỗi hàng là một list các ô (AIR, WALL, BOX, v.v.)
        self.structure = []
        max_width = 0  # Biến này dùng để lưu độ rộng lớn nhất trong các hàng (để tính kích thước bản đồ)

        # Mở file bản đồ "test<level>.txt" trong thư mục assets/sokobanLevels
        # Ví dụ nếu level=1, file sẽ là "test1.txt"
        with open("assets/sokobanLevels/test" + str(level) + ".txt") as level_file:
            # Đọc toàn bộ nội dung file, tách theo dòng (\n) => rows là list các chuỗi
            rows = level_file.read().split('\n')

            # Duyệt qua từng dòng y (mỗi dòng là 1 chuỗi)
            for y in range(len(rows)):
                level_row = []  # Danh sách chứa các ô thuộc dòng y
                # Cập nhật max_width nếu chiều dài dòng này lớn hơn max_width
                if len(rows[y]) > max_width:
                    max_width = len(rows[y])

                # Duyệt qua từng ký tự x trong dòng y
                for x in range(len(rows[y])):
                    if rows[y][x] == ' ':
                        # ' ' biểu thị ô trống => SOKOBAN.AIR
                        level_row.append(SOKOBAN.AIR)
                    elif rows[y][x] == '#':
                        # '#' biểu thị tường (wall)
                        level_row.append(SOKOBAN.WALL)
                    elif rows[y][x] == 'B':
                        # 'B' biểu thị thùng (box)
                        level_row.append(SOKOBAN.BOX)
                    elif rows[y][x] == '.':
                        # '.' biểu thị mục tiêu (target)
                        level_row.append(SOKOBAN.TARGET)
                    # Đoạn code bên dưới bị comment, có thể là ký hiệu khác của mục tiêu
                    # elif rows[y][x] == '+':
                    #     level_row.append(SOKOBAN.TARGET)
                    #     self.position_player = [x,y]
                    elif rows[y][x] == 'X':
                        # 'X' biểu thị thùng đang nằm trên mục tiêu (target filled)
                        level_row.append(SOKOBAN.TARGET_FILLED)
                    elif rows[y][x] == '&':
                        # '&' biểu thị vị trí người chơi, 
                        # đồng thời vẫn là ô trống (AIR) khi vẽ bản đồ
                        level_row.append(SOKOBAN.AIR)
                        # Lưu lại vị trí người chơi để khởi tạo sau này
                        self.position_player = [x,y]
                
                # Thêm danh sách hàng vừa xử lý vào self.structure
                self.structure.append(level_row)

        # Tính toán chiều rộng (width) và chiều cao (height) của level 
        # (theo đơn vị pixel) dựa vào SOKOBAN.SPRITESIZE (mặc định là 32px)
        self.width = max_width * SOKOBAN.SPRITESIZE
        # len(rows) là số dòng, -1 có thể là do có một dòng trống cuối file
        self.height = (len(rows) - 1) * SOKOBAN.SPRITESIZE

    def cancel_last_move(self, player, interface):
        # Phương thức khôi phục lại cấu trúc bàn chơi trước bước đi cuối cùng
        # Nếu last_structure_state có lưu, ta phục hồi
        if self.last_structure_state:
            # Phục hồi self.structure từ last_structure_state
            self.structure = self.last_structure_state
            # Phục hồi vị trí người chơi
            player.pos = self.last_player_pos
            # Đổi màu text "Undo" thành xám (GREY) để báo đã hoàn tác
            interface.colorTxtCancel = SOKOBAN.GREY
            # Xoá bỏ bản sao lưu sau khi đã khôi phục
            self.last_structure_state = None
        else:
            # Nếu không có dữ liệu để undo
            print("No previous state")

    def render(self, window, textures):
        # Hàm render dùng để vẽ toàn bộ cấu trúc (tường, thùng, mục tiêu, v.v.) lên màn hình
        # Duyệt qua từng ô trong self.structure
        for y in range(len(self.structure)):
            for x in range(len(self.structure[y])):
                # Nếu giá trị ô (self.structure[y][x]) nằm trong dict textures
                # (tức là WALL, BOX, TARGET, TARGET_FILLED, PLAYER, ...)
                # thì ta dùng window.blit() để vẽ hình tương ứng
                if self.structure[y][x] in textures:
                    window.blit(textures[self.structure[y][x]],
                                (x * SOKOBAN.SPRITESIZE, y * SOKOBAN.SPRITESIZE))
                else:
                    # Trường hợp ô đó không nằm trong textures (vd. kịch bản hiếm),
                    # ta tự vẽ hình chữ nhật.
                    if self.structure[y][x] == SOKOBAN.TARGET_FILLED:
                        # Nếu là ô có thùng đặt trên mục tiêu, tô màu xanh lá (0,255,0)
                        pygame.draw.rect(window,
                                         (0,255,0),
                                         (x * SOKOBAN.SPRITESIZE,
                                          y * SOKOBAN.SPRITESIZE,
                                          SOKOBAN.SPRITESIZE,
                                          SOKOBAN.SPRITESIZE))
                    else:
                        # Mặc định thì tô màu trắng
                        pygame.draw.rect(window,
                                         SOKOBAN.WHITE,
                                         (x * SOKOBAN.SPRITESIZE,
                                          y * SOKOBAN.SPRITESIZE,
                                          SOKOBAN.SPRITESIZE,
                                          SOKOBAN.SPRITESIZE))
